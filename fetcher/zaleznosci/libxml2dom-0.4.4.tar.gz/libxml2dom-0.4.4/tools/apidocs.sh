#!/bin/sh

epydoc --docformat=plaintext -o apidocs libxml2dom/*.py libxml2dom/macrolib/*.py
